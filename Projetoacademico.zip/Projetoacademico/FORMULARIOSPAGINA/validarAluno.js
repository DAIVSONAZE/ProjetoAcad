function ValidaFormAluno(){
	// Registrar alterar dados pessoais(aluno)
	
	d = document.formas;
	if(d.nomeAlu.value == ""){
		alert("O campo NOME deve ser preenchido!");
		d.nomeAlu.style.backgroundColor="blue";
		d.nomeAlu.style.color="#ffffff";
		d.nomeAlu.focus();
		return false;
	}
	
	
	if(d.Anasci.value == ""){
		alert("O campo DATANASCIMENTO dever ser preenchido!");
		d.Anasci.style.backgroundColor="blue";
		d.Anasci.style.color="#ffffff";
		d.Anasci.focus();
		return false;
		
	}
	
	if(d.Pende.value == ""){
		alert("O campo LOGRADOURO dever ser preenchido!");
		d.Pende.style.backgroundColor="blue";
		d.Pende.style.color="#ffffff";
		d.Pende.focus();
		return false;
	}
	
	
	
	if(d.Pnumer.value ==""){
		alert("O campo N?deve ser preenchido!");
		d.Pnumer.style.backgroundColor="blue";
		d.Pnumer.style.color="#ffffff";
		d.Pnumer.focus();
		return false;
		
	}
	
	if(d.Ptel.value ==""){
		alert("O campo TELEFONE deve ser preenchido!");
		d.Ptel.style.backgroundColor="blue";
		d.Ptel.style.color="#ffffff";
		d.Ptel.focus();
		return false;
		
	}
	
	
	if(d.Acidade.value ==""){
		alert("O campo CIDADE deve ser preenchido!");
		d.Acidade.style.backgroundColor="blue";
		d.Acidade.style.color="#ffffff";
		d.Acidade.focus();
		return false;
		
	}
	
	
	
	
	
}

function validaFormSemestre(){

// Registrar cadastramento do aluno
	d = document.formas;
		if(d.semestcurso.value == ""){
			alert("O campo SEMESTRE deve ser preenchido!");
			d.semestcurso.style.backgroundColor="blue";
			d.semestcurso.style.color="#ffffff";
			d.semestcurso.focus();
			return false;
		}
		
		
}

		
// CAMPO DE MASCARAS

//adiciona mascara de data (alterar dados pessoais)
function MascaraData(Anasci){  // E COLOCADO O "NAME" DESTRO DESTE PARENTESES.
        if(mascaraInteiro(Anasci)==false){
                event.returnValue = false;
        }       
        return formataCampo(Anasci, '00/00/0000', event);
}

//valida data (alterar dados pessoais)
function ValidaData(Anasci){
        exp = /\d{2}\/\d{2}\/\d{4}/
        if(!exp.test(Anasci.value))
                alert('Data Invalida!');                        
}


//adiciona mascara ao telefone
function MascaraTelefone(Ptel){  
        if(mascaraInteiro(Ptel)==false){
                event.returnValue = false;
        }       
        return formataCampo(Ptel, '(00) 0000-0000', event);
}

//valida telefone
function ValidaTelefone(Ptel){
        exp = /\(\d{2}\)\ \d{4}\-\d{4}/
        if(!exp.test(tel.value))
                alert('Numero de Telefone Invalido!');
}

















