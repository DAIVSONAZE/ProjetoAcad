﻿function validaFormSecre(){
	
	// Registrar cadastramento do professor (secretaria)
	d = document.formas;
	if(d.Pronome.value == ""){
		alert("O campo NOME deve ser preenchido!");
		d.Pronome.style.backgroundColor="blue";
		d.Pronome.style.color="#ffffff";
		d.Pronome.focus();
		return false;
		
	}
	
	
	if(d.Pronasci.value ==""){
		alert("O campo DATADENASCIMENTO deve ser preenchido!");
		d.Pronasci.style.backgroundColor="blue";
		d.Pronasci.style.color="#ffffff";
		d.Pronasci.focus();
		return false;
		
		
		
	}
	
	
	if(d.Pcpf.value == ""){
		alert("O campo CPF ver ser preenchido!");
		d.Pcpf.style.backgroundColor="blue";
		d.Pcpf.style.color="#ffffff";
		d.Pcpf.focus();
		return false;
		
	}
	
	if(d.Proende.value ==""){
		alert("O campo LOGRADOURO deve ser preenchido!");
		d.Proende.style.backgroundColor="blue";
		d.Proende.style.color="#ffffff";
		d.Proende.focus();
		return false;
		
		
		
	}
	
	if(d.PnumeroAl.value ==""){
		alert("O campo Nº deve ser preenchido!");
		d.PnumeroAl.style.backgroundColor="blue";
		d.PnumeroAl.style.color="#ffffff";
		d.PnumeroAl.focus();
		return false;
		
	}
	
	
	if(d.Ptelefon.value ==""){
		alert("O campo TELEFONE deve ser preenchido!");
		d.Ptelefon.style.backgroundColor="blue";
		d.Ptelefon.style.color="#ffffff";
		d.Ptelefon.focus();
		return false;
		
	}
	
	if(d.Pcidade.value==""){
		alert("O campo CIDADE dever ser preenchido!");
		d.Pcidade.style.backgroundColor="blue";
		d.Pcidade.style.color="#ffffff";
		d.Pcidade.focus();
		return false;
		
		
		
	}

	
}


//ESPACO PARA MASCARAS


//adiciona mascara de data
function MascaraData(Pronasci){
        if(mascaraInteiro(Pronasci)==false){
                event.returnValue = false;
        }       
        return formataCampo(Pronasci, '00/00/0000', event);
}

//valida data
function ValidaData(Pronasci){
        exp = /\d{2}\/\d{2}\/\d{4}/
        if(!exp.test(Pronasci.value))
                alert('Data Invalida!');  			
}

//adiciona mascara ao CPF
function MascaraCPF(Pcpf){
        if(mascaraInteiro(Pcpf)==false){
                event.returnValue = false;
        }       
        return formataCampo(Pcpf, '000.000.000-00', event);
}


//valida o CPF digitado
function ValidarCPF(Objcpf){
        var cpf = Objcpf.value;
        exp = /\.|\-/g
        cpf = cpf.toString().replace( exp, "" ); 
        var digitoDigitado = eval(cpf.charAt(9)+cpf.charAt(10));
        var soma1=0, soma2=0;
        var vlr =11;

        for(i=0;i<9;i++){
                soma1+=eval(cpf.charAt(i)*(vlr-1));
                soma2+=eval(cpf.charAt(i)*vlr);
                vlr--;
        }       
        soma1 = (((soma1*10)%11)==10 ? 0:((soma1*10)%11));
        soma2=(((soma2+(2*soma1))*10)%11);

        var digitoGerado=(soma1*10)+soma2;
        if(digitoGerado!=digitoDigitado)        
                alert('CPF Invalido!');         
}

//adiciona mascara ao telefone
function MascaraTelefone(Ptelefon){  
        if(mascaraInteiro(Ptelefon)==false){
                event.returnValue = false;
        }       
        return formataCampo(Ptelefon, '(00) 0000-0000', event);
}

//valida telefone
function ValidaTelefone(Ptelefon){
        exp = /\(\d{2}\)\ \d{4}\-\d{4}/
        if(!exp.test(Ptelefon.value))
                alert('Numero de Telefone Invalido!');
}






















