﻿//Script de Banco de Dados


// Banco de Dados PROFESSOR:
CREATE_TABLE_registrarfaltasaluno{
	
	aluno_VARCHAR(40),
	disciplinas_VARCHAR(20),
	data_VARCAHR(10),
	numerodefaltas_int(2),
	
	
};

CREATE_TABLE_registrarnotasaluno{
	
	aluno_VARCHAR(40),
	disciplinas_VARCHAR(20),
	notas_int(2),
	
	
	
};

CREATE_TABLE_cadastrarprojetopesquisa{
	
	titulodoprojeto_VARCHAR(60),
	descricao_VARCHAR(250),

};


//Banco de Dados ALUNO:

CREATE_TABLE_cadastramentodoaluno{
	
	nome_VARCHAR(40),
	data_VARCAHR(10),
	logradouro_VARCHAR(30),
	numero_int(4),
	telefone_VARCAHR(13),
	cidade_VARCHAR(40),
	
};

CREATE_TABLE_visualizarnotasfaltas{
	
	aluno_VARCHAR(40),
	disciplinas_VARCHAR(20),
	
	
};

CREATE_TABLE_emitircomprovantedematricula{
	
	aluno_VARCHAR(40),
	semestre_VARCHAR(8),
	
	
};

//Banco de Dados SECRETARIA:

CREATE_TABLE_cadastramentoprofessor{
	
	
	nome_VARCHAR(40),
	data_VARCAHR(10),
	cpf_int(13)
	logradouro_VARCHAR(30),
	numero_int(4),
	telefone_VARCAHR(13),
	cidade_VARCHAR(40),

};

CREATE_TABLE_realizarmatricula{

	semestre_VARCHAR(8),


};




