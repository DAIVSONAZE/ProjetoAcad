﻿function validaFormDataNumer(){
	
	// Registrar faltas
	
           d = document.formas;
           //validar data
           if (d.data.value == ""){
                     alert("O campo DATA  deve ser preenchido!");
                     d.data.style.backgroundColor="blue";
                     d.data.style.color="#ffffff";
                    d.data.focus();
                     return false;
           }
          
		   
		    
            //validar Nº
           if (d.Nfaltas.value == ""){
                     alert("O campo Nfaltas  deve ser preenchido!");
                     d.Nfaltas.style.backgroundColor="blue";
                     d.Nfaltas.style.color="#ffffff";
                    d.Nfaltas.focus();
                     return false;
		   
		   }
		   
		   		   document.formas.submit();
		   
}

function validaForm1(){
	
	// Registrar notas
	
           d = document.formas;

		   
		    //validar Notas
           if (d.Regnotas.value == ""){
                     alert("O campo Notas  deve ser preenchido!");
                     d.Regnotas.style.backgroundColor="blue";
                     d.Regnotas.style.color="#ffffff";
                    d.Regnotas.focus();
                     return false;
		   
		   }
		   
		  document.formas.submit();
		   
}

		   
		   
		   
function validaFormProjeto(){
	
	// Registrar projeto e pesquisa
	
           d = document.formas;
		   
		    //validar texto
		   if (d.Tituloprojeto.value == ""){
                     alert("Digite o Titulo do projeto!");
                     d.Tituloprojeto.style.backgroundColor="blue";
                     d.Tituloprojeto.style.color="#ffffff";
                     d.Tituloprojeto.focus();
					 return false;
                     
		   }


	
	// Registrar 
	
           d = document.formas;
		    //validar mensagem
		   if (d.mensagem.value == ""){
                     alert("Digite a mensagem!");
                     d.mensagem.style.backgroundColor="blue";
                     d.mensagem.style.color="#ffffff";
                     d.mensagem.focus();
					 return false;
                     
           }
		   
		   
		
		   
		   document.formas.submit();
		   
}

//ESPACO PARA MASCARAS

//adiciona mascara de data
function MascaraData(data){
        if(mascaraInteiro(data)==false){
                event.returnValue = false;
        }       
        return formataCampo(data, '00/00/0000', event);
}

//valida data
function ValidaData(data){
        exp = /\d{2}\/\d{2}\/\d{4}/
        if(!exp.test(data.value))
                alert('Data Invalida!'); 

}


